// MARK: - WidgetFormComponents.swift (抽离通用配置组件 · 彻底消灭重复模板代码)
import SwiftUI

// MARK: - 通用调色板行
struct WidgetColorPaletteRow: View {
    let title: String
    let selectedHex: String
    let presets: [String]
    let currentColor: Color
    var onSelectHex: (String) -> Void
    var onPickColor: (Color) -> Void
    
    @ObservedObject var appearance = SystemAppearance.shared
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(title).font(.system(size: 15, weight: appearance.systemFontWeight))
                Spacer()
                ColorPicker("", selection: Binding(get: { currentColor }, set: { onPickColor($0) })).labelsHidden()
            }
            HStack(spacing: 9) {
                ForEach(presets, id: \.self) { hex in
                    let isSelected = selectedHex.uppercased() == hex.uppercased()
                    Circle().fill(Color(hex: hex)).frame(width: 24, height: 24)
                        .overlay(Circle().stroke(Color.blue, lineWidth: isSelected ? 2.2 : 0))
                        .overlay(Circle().stroke(Color.primary.opacity(0.12), lineWidth: 0.6))
                        .onTapGesture { onSelectHex(hex) }
                }
            }
        }
    }
}

// MARK: - 通用字体粗细胶囊选择器
struct WidgetFontWeightPicker: View {
    let title: String
    @Binding var selectedWeightName: String
    
    @ObservedObject var appearance = SystemAppearance.shared
    private let weightOptions = [("常规", "regular"), ("中等", "medium"), ("半粗", "semibold"), ("粗体", "bold"), ("细体", "light")]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.system(size: 15, weight: appearance.systemFontWeight))
            HStack(spacing: 8) {
                ForEach(weightOptions, id: \.1) { item in
                    let isSelected = selectedWeightName == item.1
                    Button(action: { selectedWeightName = item.1 }) {
                        Text(item.0.tr)
                            .font(.system(size: 12, weight: isSelected ? .semibold : appearance.systemFontWeight))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(isSelected ? Color.blue : Color(UIColor.tertiarySystemFill))
                            .foregroundColor(isSelected ? .white : .primary)
                            .clipShape(Capsule())
                    }
                }
            }
        }
    }
}

// MARK: - 通用文字与字号/颜色复合编辑段
struct WidgetTextSectionEditor: View {
    let sectionTitle: String
    let placeholder: String
    @Binding var text: String
    @Binding var size: Double
    let minSize: Double
    let maxSize: Double
    @Binding var selectedWeightName: String
    let selectedHex: String
    let currentColor: Color
    var onSelectHex: (String) -> Void
    var onPickColor: (Color) -> Void
    
    @ObservedObject var appearance = SystemAppearance.shared
    private let textColors = ["#000000", "#FFFFFF", "#3C3C43", "#8E8E93", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(sectionTitle).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
            TextField(placeholder, text: $text)
                .font(.subheadline)
                .padding(10)
                .background(Color(UIColor.tertiarySystemFill))
                .cornerRadius(10)
            
            Divider()
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("字号大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                    Spacer()
                    Text(String(format: "%.1f pt", size)).font(.caption).foregroundColor(.secondary)
                }
                Slider(value: $size, in: minSize...maxSize, step: 0.5)
            }
            
            Divider()
            WidgetFontWeightPicker(title: "字体粗细".tr, selectedWeightName: $selectedWeightName)
            
            Divider()
            WidgetColorPaletteRow(
                title: "字体颜色".tr,
                selectedHex: selectedHex,
                presets: textColors,
                currentColor: currentColor,
                onSelectHex: onSelectHex,
                onPickColor: onPickColor
            )
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .padding(.horizontal, 16)
    }
}
