// MARK: - 9. HomeScreenView (组件对齐图标底边 · 终极对齐版)
import SwiftUI
import PhotosUI

enum DraggingWidgetType: String, Equatable {
    case ins, korean, photo, bubble
}

struct HomeWallpaperBackgroundView: View {
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    
    var body: some View {
        Group {
            if let img = wallpaperManager.homeScreenImage {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFill()
            } else {
                NativeImage(data: wallpaperManager.homeScreenData)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .clipped()
    }
}

@MainActor
final class WidgetDragCoordinator: ObservableObject {
    @Published var activeType: DraggingWidgetType? = nil
    let positionTracker = DragPositionTracker()
    var initialOriginY: CGFloat = 0
    var initialOriginX: CGFloat = 0
    var lastTouchLocation: CGPoint = .zero
    
    func start(type: DraggingWidgetType, originX: CGFloat, originY: CGFloat) {
        self.activeType = type
        self.initialOriginX = originX
        self.initialOriginY = originY
        self.positionTracker.offset = .zero
    }
    
    func update(translation: CGSize) {
        self.positionTracker.offset = translation
    }
    
    func reset() {
        self.activeType = nil
        self.positionTracker.offset = .zero
        self.initialOriginX = 0
        self.initialOriginY = 0
        self.lastTouchLocation = .zero
    }
}

// 统一标准：每个图标格子容器占用高 80pt（顶部固定 60pt 为 AppIcon，底部 20pt 为文字区）
struct GridSlotView: View {
    let slotIndex: Int
    let item: AppItem?
    let isEditing: Bool
    let isBeingDragged: Bool
    let textColor: Color
    let customTitle: String?
    let customImageData: Data?
    let onLaunch: () -> Void
    let onEnterEdit: () -> Void
    let onDragStart: (AppItem, CGPoint) -> Void
    let onDragChange: (CGPoint) -> Void
    let onDragEnd: (CGPoint) -> Void
    
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var iconManager = CustomIconManager.shared
    
    @GestureState private var dragActive: Bool = false
    @State private var lastDragLocation: CGPoint = .zero
    
    var body: some View {
        ZStack(alignment: .top) {
            if let item = item {
                let displayTitle = item.localizedTitle(customManager: iconManager, lang: lang)
                if isEditing {
                    AppIcon(icon: item.icon, color: item.color, title: displayTitle, textColor: textColor, customImageData: customImageData) {}
                        .id("app_\(item.id)")
                        .opacity(isBeingDragged ? 0.0 : 1.0)
                        .transition(.identity)
                        .highPriorityGesture(
                            DragGesture(minimumDistance: 0, coordinateSpace: .global)
                                .updating($dragActive) { _, state, _ in
                                    state = true 
                                }
                                .onChanged { val in
                                    lastDragLocation = val.location
                                    if !isBeingDragged { onDragStart(item, val.location) }
                                    else { onDragChange(val.location) }
                                }
                                .onEnded { val in onDragEnd(val.location) }
                        )
                        .onChange(of: dragActive) { _, isActive in
                            if !isActive && isBeingDragged {
                                onDragEnd(lastDragLocation)
                            }
                        }
                } else {
                    AppIcon(icon: item.icon, color: item.color, title: displayTitle, textColor: textColor, customImageData: customImageData) { onLaunch() }
                        .id("app_\(item.id)")
                        .transition(.identity)
                        .simultaneousGesture(
                            LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                                if !isEditing {
                                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                    onEnterEdit()
                                }
                            }
                        )
                }
            } else {
                Color.clear
                    .contentShape(Rectangle())
                    .simultaneousGesture(
                        LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                            if !isEditing {
                                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                onEnterEdit()
                            }
                        }
                    )
                    .transition(.identity)
            }
        }
        .modifier(JiggleModifier(isEditing: isEditing, isWidget: false, customDelayIndex: slotIndex))
        .frame(maxWidth: .infinity)
        .frame(height: 80, alignment: .top)
        .contentShape(Rectangle())
        .transition(.identity)
    }
}

struct DockItemView: View {
    let dockIndex: Int
    let item: AppItem
    let isEditing: Bool
    let isBeingDragged: Bool
    let customImageData: Data?
    let onLaunch: () -> Void
    let onEnterEdit: () -> Void
    let onDragStart: (AppItem, CGPoint) -> Void
    let onDragChange: (CGPoint) -> Void
    let onDragEnd: (CGPoint) -> Void
    
    @GestureState private var dragActive: Bool = false
    @State private var lastDragLocation: CGPoint = .zero
    
    var body: some View {
        ZStack {
            if isEditing {
                AppIcon(icon: item.icon, color: item.color, customImageData: customImageData) {}
                    .id("dock_\(item.id)")
                    .opacity(isBeingDragged ? 0.0 : 1.0)
                    .transition(.identity)
                    .highPriorityGesture(
                        DragGesture(minimumDistance: 0, coordinateSpace: .global)
                            .updating($dragActive) { _, state, _ in
                                state = true
                            }
                            .onChanged { val in
                                lastDragLocation = val.location
                                if !isBeingDragged { onDragStart(item, val.location) }
                                else { onDragChange(val.location) }
                            }
                            .onEnded { val in onDragEnd(val.location) }
                    )
                    .onChange(of: dragActive) { _, isActive in
                        if !isActive && isBeingDragged {
                            onDragEnd(lastDragLocation)
                        }
                    }
            } else {
                AppIcon(icon: item.icon, color: item.color, customImageData: customImageData) { onLaunch() }
                    .id("dock_\(item.id)")
                    .transition(.identity)
                    .simultaneousGesture(
                        LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                            if !isEditing {
                                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                onEnterEdit()
                            }
                        }
                    )
            }
        }
        .modifier(JiggleModifier(isEditing: isEditing, isWidget: false, customDelayIndex: abs(item.id.hashValue) % 10))
        .transition(.identity)
    }
}

struct ActiveDragOverlay: View {
    @ObservedObject var coordinator: DragCoordinator
    @ObservedObject var tracker: DragPositionTracker
    @ObservedObject var iconManager = CustomIconManager.shared
    @ObservedObject var lang = LanguageManager.shared
    let rootOrigin: CGPoint
    let screenH: CGFloat
    let contentColor: Color
    
    var body: some View {
        Group {
            if let dragged = coordinator.activeDraggingItem {
                let localPoint = CGPoint(
                    x: tracker.location.x - rootOrigin.x,
                    y: tracker.location.y - rootOrigin.y
                )
                let isNearDock = localPoint.y >= (screenH - 171)
                let shouldHideTitle = isNearDock || (coordinator.activeDragSource?.isDock == true && localPoint.y >= (screenH - 171))
                let displayTitle = dragged.localizedTitle(customManager: iconManager, lang: lang)
                
                AppIcon(
                    icon: dragged.icon,
                    color: dragged.color,
                    title: displayTitle,
                    textColor: contentColor.opacity(shouldHideTitle ? 0.0 : 1.0),
                    customImageData: iconManager.getIcon(for: dragged.id)
                ) {}
                    .frame(width: 60, height: 60)
                    .position(localPoint)
                    .allowsHitTesting(false)
                    .zIndex(99999)
            }
        }
    }
}

struct GlobalWidgetDragOverlay: View {
    @ObservedObject var widgetCoordinator: WidgetDragCoordinator
    @ObservedObject var tracker: DragPositionTracker
    let screenW: CGFloat
    let gridTopOffsetY: CGFloat
    let widget4xHeight: CGFloat
    let widget2xHeight: CGFloat
    
    @ObservedObject var insWidgetManager = InsPostWidgetManager.shared
    @ObservedObject var photoWidgetManager = PhotoWidgetManager.shared
    @ObservedObject var chatBubbleManager = ChatBubbleWidgetManager.shared
    @ObservedObject var koreanWidgetManager = KoreanMessageWidgetManager.shared
    
    var body: some View {
        Group {
            if let type = widgetCoordinator.activeType {
                let fullWidth = max(0, screenW - 48)
                let halfWidth = max(0, (fullWidth - 18) / 2.0)
                
                Group {
                    switch type {
                    case .ins:
                        InsPostWidget4x4View(manager: insWidgetManager, isEditing: false)
                            .frame(width: fullWidth, height: widget4xHeight)
                        
                    case .korean:
                        KoreanMessageWidget4x2View(manager: koreanWidgetManager, isEditing: false)
                            .frame(width: halfWidth, height: widget2xHeight)
                        
                    case .photo:
                        PhotoWidget4x2View(imageData: photoWidgetManager.widgetImageData, isEditing: false)
                            .frame(width: fullWidth, height: widget2xHeight)
                        
                    case .bubble:
                        ChatBubbleWidget2x2View(
                            imageData: chatBubbleManager.widgetImageData,
                            firstBubbleText: chatBubbleManager.firstBubbleText,
                            secondBubbleText: chatBubbleManager.secondBubbleText,
                            isTransparent: chatBubbleManager.isTransparentBackground,
                            bubbleColor: chatBubbleManager.bubbleColor,
                            bubbleTextColor: chatBubbleManager.bubbleTextColor,
                            dateTextColor: chatBubbleManager.dateTextColor,
                            bubbleTextWeight: chatBubbleManager.bubbleTextWeight,
                            isEditing: false
                        )
                        .frame(width: halfWidth, height: widget2xHeight)
                    }
                }
                .scaleEffect(1.02)
                .shadow(color: Color.black.opacity(0.18), radius: 14, y: 7)
                .offset(
                    x: 24.0 + widgetCoordinator.initialOriginX + tracker.offset.width,
                    y: gridTopOffsetY + widgetCoordinator.initialOriginY + tracker.offset.height
                )
                .allowsHitTesting(false)
                .zIndex(99999)
                .transition(.identity)
            }
        }
        .transaction { transaction in
            transaction.animation = nil
        }
    }
}

struct HomeScreenView: View {
    @Binding var isUnlocked: Bool
    
    @StateObject private var viewModel = HomeScreenViewModel()
    @StateObject private var dragCoordinator = DragCoordinator()
    @StateObject private var widgetCoordinator = WidgetDragCoordinator()
    
    @ObservedObject var insWidgetManager = InsPostWidgetManager.shared
    @ObservedObject var photoWidgetManager = PhotoWidgetManager.shared
    @ObservedObject var chatBubbleManager = ChatBubbleWidgetManager.shared
    @ObservedObject var koreanWidgetManager = KoreanMessageWidgetManager.shared
    @ObservedObject var iconManager = CustomIconManager.shared
    
    @State private var activeAppId: String? = nil
    @State private var currentPage = 0
    @State private var showAddWidgetSheet = false
    @State private var showInsPhotoPicker = false
    
    @State private var selectedWidgetPhotoItem: PhotosPickerItem? = nil
    @State private var selectedKoreanPhotoItem: PhotosPickerItem? = nil
    @State private var selectedInsPostPhotoItem: PhotosPickerItem? = nil
    
    @State private var lastEditTriggerTime: Date = .distantPast
    
    @State private var currentEdgeDirection: Int? = nil
    @State private var edgePagingTask: Task<Void, Never>? = nil
    @State private var isPagingAnimating: Bool = false
    
    @State private var showDotsTemporarily: Bool = false
    @State private var hideDotsTimer: Task<Void, Never>? = nil
    
    private let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
    
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    private let columns: [GridItem] = Array(repeating: GridItem(.flexible(), spacing: 18), count: 4)
    var contentColor: Color { wallpaperManager.homeTextColor }
    
    private func enterEditMode() {
        impactFeedback.impactOccurred()
        lastEditTriggerTime = Date()
        withAnimation(.easeInOut(duration: 0.22)) {
            viewModel.isEditing = true
        }
    }
    
    private func exitEditMode() {
        cancelEdgePaging()
        impactFeedback.impactOccurred()
        withAnimation(.easeInOut(duration: 0.22)) {
            viewModel.isEditing = false
            viewModel.compactPages()
            currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
        }
    }
    
    private func checkIsStillInEdge(dir: Int, screenW: CGFloat) -> Bool {
        let edgeThreshold: CGFloat = 52.0
        let touchX = widgetCoordinator.lastTouchLocation.x
        return (dir < 0) ? (touchX <= edgeThreshold) : (touchX >= (screenW - edgeThreshold))
    }
    
    private func handleAppEdgeDrag(location: CGPoint, screenW: CGFloat, screenH: CGFloat, dockTriggerH: CGFloat) {
        guard viewModel.isEditing else { return }
        widgetCoordinator.lastTouchLocation = location
        
        let isDockArea = location.y >= (screenH - dockTriggerH)
        guard !isDockArea else {
            cancelEdgePaging()
            return
        }
        
        let isLeft = checkIsStillInEdge(dir: -1, screenW: screenW)
        let isRight = checkIsStillInEdge(dir: 1, screenW: screenW)
        
        if isLeft {
            if currentPage > 0 {
                startEdgePaging(direction: -1, screenW: screenW)
            } else {
                cancelEdgePaging()
            }
        } else if isRight {
            let canTurnToExistingNext = currentPage < viewModel.totalPages() - 1
            let canExpandNewPage = (currentPage == viewModel.totalPages() - 1) && !viewModel.isPageEmpty(currentPage)
            
            if canTurnToExistingNext || canExpandNewPage {
                startEdgePaging(direction: 1, screenW: screenW)
            } else {
                cancelEdgePaging()
            }
        } else {
            cancelEdgePaging()
        }
    }
    
    private func startEdgePaging(direction: Int, screenW: CGFloat) {
        if currentEdgeDirection == direction && edgePagingTask != nil {
            return
        }
        
        cancelEdgePaging()
        currentEdgeDirection = direction
        
        edgePagingTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 220_000_000)
            
            while !Task.isCancelled {
                guard let dir = currentEdgeDirection else { break }
                guard checkIsStillInEdge(dir: dir, screenW: screenW) else { break }
                
                if dir < 0 {
                    if currentPage > 0 {
                        impactFeedback.impactOccurred()
                        isPagingAnimating = true
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
                            currentPage -= 1
                        }
                        try? await Task.sleep(nanoseconds: 360_000_000)
                        isPagingAnimating = false
                    } else {
                        break
                    }
                } else if dir > 0 {
                    if currentPage < viewModel.totalPages() - 1 {
                        impactFeedback.impactOccurred()
                        isPagingAnimating = true
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
                            currentPage += 1
                        }
                        try? await Task.sleep(nanoseconds: 360_000_000)
                        isPagingAnimating = false
                    } else if currentPage == viewModel.totalPages() - 1 {
                        if !viewModel.isPageEmpty(currentPage) {
                            impactFeedback.impactOccurred()
                            isPagingAnimating = true
                            
                            viewModel.triggerExpandNewPage()
                            try? await Task.sleep(nanoseconds: 45_000_000)
                            
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
                                currentPage += 1
                            }
                            try? await Task.sleep(nanoseconds: 360_000_000)
                            isPagingAnimating = false
                            break
                        } else {
                            break
                        }
                    }
                }
                
                try? await Task.sleep(nanoseconds: 280_000_000)
                guard !Task.isCancelled else { break }
            }
            
            currentEdgeDirection = nil
            edgePagingTask = nil
        }
    }
    
    private func cancelEdgePaging() {
        currentEdgeDirection = nil
        edgePagingTask?.cancel()
        edgePagingTask = nil
    }
    
    var body: some View {
        GeometryReader { screenGeo in
            let screenW = screenGeo.size.width
            let screenH = screenGeo.size.height
            let rootOrigin = screenGeo.frame(in: .global).origin
            let topInset = screenGeo.safeAreaInsets.top
            let bottomInset = screenGeo.safeAreaInsets.bottom
            
            // 1. 顶部 Header 高度
            let headerH: CGFloat = max(topInset, 44.0)
            
            // 2. 底部 Dock 与搜索栏安全边距
            let dockH: CGFloat = 88.0
            let dockBottomPadding: CGFloat = max(bottomInset - 10.0, 14.0)
            let indicatorH: CGFloat = 26.0
            let indicatorToDockGap: CGFloat = 22.0
            let bottomControlsH = dockH + dockBottomPadding + indicatorH + indicatorToDockGap
            
            // 3. 计算 6 行桌面网格纯可用高度
            let availableForGrid = max(480.0, screenH - headerH - bottomControlsH - 24.0)
            let rowSpacing: CGFloat = max(8.0, min(22.0, (availableForGrid - 480.0) / 5.0))
            let rowPitch: CGFloat = 80.0 + rowSpacing
            
            // 🌟🌟🌟 严格对齐图标底边（扣除最后一排 20pt 文字区）🌟🌟🌟
            // 2 行小组件高度 = 1 个完整格子(80) + 间隙(S) + 第二排图标(60) = 140 + S
            let widget2xHeight: CGFloat = 140.0 + rowSpacing
            // 4 行大组件高度 = 3 个完整格子与间隙(3 * (80 + S)) + 第四排图标(60) = 300 + 3S
            let widget4xHeight: CGFloat = 300.0 + 3.0 * rowSpacing
            
            let gridTotalHeight: CGFloat = 6.0 * 80.0 + 5.0 * rowSpacing
            let dockTriggerH = dockH + dockBottomPadding + 20.0
            
            ZStack(alignment: .topLeading) {
                HomeWallpaperBackgroundView()
                    .frame(width: screenW, height: screenH)
                    .ignoresSafeArea(.all)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        guard Date().timeIntervalSince(lastEditTriggerTime) > 0.4 else { return }
                        if viewModel.isEditing { exitEditMode() }
                    }
                    .simultaneousGesture(
                        LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                            if !viewModel.isEditing { enterEditMode() }
                        }
                    )
                
                VStack(spacing: 0) {
                    topHeaderContainerView(headerH: headerH)
                    
                    gridContainerView(
                        rootOrigin: rootOrigin,
                        screenW: screenW,
                        screenH: screenH,
                        headerH: headerH,
                        rowPitch: rowPitch,
                        rowSpacing: rowSpacing,
                        widget4xHeight: widget4xHeight,
                        widget2xHeight: widget2xHeight,
                        dockTriggerH: dockTriggerH
                    )
                    .frame(height: gridTotalHeight)
                    
                    Spacer(minLength: 12)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            guard Date().timeIntervalSince(lastEditTriggerTime) > 0.4 else { return }
                            if viewModel.isEditing { exitEditMode() }
                        }
                        .simultaneousGesture(
                            LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                                if !viewModel.isEditing { enterEditMode() }
                            }
                        )
                    
                    VStack(spacing: indicatorToDockGap) {
                        indicatorView
                        dockBarView(
                            rootOrigin: rootOrigin,
                            screenW: screenW,
                            screenH: screenH,
                            dockH: dockH,
                            dockBottom: dockBottomPadding,
                            dockTriggerH: dockTriggerH,
                            headerH: headerH,
                            rowPitch: rowPitch
                        )
                    }
                }
                .frame(width: screenW, height: screenH)
                
                GlobalWidgetDragOverlay(
                    widgetCoordinator: widgetCoordinator,
                    tracker: widgetCoordinator.positionTracker,
                    screenW: screenW,
                    gridTopOffsetY: headerH,
                    widget4xHeight: widget4xHeight,
                    widget2xHeight: widget2xHeight
                )
                
                ActiveDragOverlay(
                    coordinator: dragCoordinator,
                    tracker: dragCoordinator.positionTracker,
                    rootOrigin: rootOrigin,
                    screenH: screenH,
                    contentColor: contentColor
                )
            }
            .overlay(
                homeIndicatorBar
                    .opacity(appearance.hideHomeIndicator ? 0.0 : 1.0)
                    .animation(.easeInOut(duration: 0.25), value: appearance.hideHomeIndicator),
                alignment: .bottom
            )
            .gesture(lockDragGesture)
        }
        .fontWeight(appearance.systemFontWeight)
        .ignoresSafeArea(.all)
        .ignoresSafeArea(.keyboard)
        .statusBarHidden(true)
        .persistentSystemOverlays(appearance.hideHomeIndicator ? .hidden : .automatic)
        .overlay {
            ZStack {
                if let activeId = activeAppId, let appDef = AppRegistry.shared.registeredApps[activeId] {
                    appDef.viewBuilder(Binding(
                        get: { activeAppId == activeId },
                        set: { if !$0 { activeAppId = nil } }
                    ))
                    .background(Color(UIColor.systemBackground).ignoresSafeArea())
                    .transition(.asymmetric(insertion: .opacity, removal: .move(edge: .trailing)))
                    .zIndex(999)
                }
            }
            .ignoresSafeArea()
        }
        .onAppear {
            if AppRegistry.shared.registeredApps.isEmpty {
                AppRegistry.shared.register(id: "wechat", name: "微信", icon: "message.fill", colorName: "green") { show in
                    AIWeChatView(show: show)
                }
                AppRegistry.shared.register(id: "settings", name: "设置", icon: "gearshape.fill", colorName: "gray") { show in
                    SettingsView(show: show)
                }
                AppRegistry.shared.register(id: "iscreen", name: "iScreen", icon: "square.grid.2x2.fill", colorName: "purple") { show in
                    IScreenView(show: show)
                }
                AppRegistry.shared.register(id: "phone", name: "电话", icon: "phone.fill", colorName: "green") { show in
                    PhoneView(show: show)
                }
                AppRegistry.shared.register(id: "messages", name: "信息", icon: "message.badge.filled.fill", colorName: "green") { show in
                    MessagesView(show: show)
                }
                AppRegistry.shared.register(id: "weather", name: "天气", icon: "cloud.sun.fill", colorName: "blue") { show in
                    WeatherView(show: show)
                }
                AppRegistry.shared.register(id: "anonymous", name: "匿名", icon: "mask.fill", colorName: "purple") { show in
                    AnonymousView(show: show)
                }
                AppRegistry.shared.register(id: "qimao", name: "七猫小说", icon: "book.fill", colorName: "orange") { show in
                    QimaoNovelView(show: show)
                }
                AppRegistry.shared.register(id: "icity", name: "iCity", icon: "building.2.fill", colorName: "blue") { show in
                    ICityView(show: show)
                }
                AppRegistry.shared.register(id: "notes", name: "手记", icon: "note.text", colorName: "orange") { show in
                    NotesView(show: show)
                }
            }
            
            if WidgetRegistry.shared.registeredWidgets.isEmpty {
                WidgetRegistry.shared.registerInsWidget()
                WidgetRegistry.shared.registerKoreanWidget()
                WidgetRegistry.shared.registerBubbleWidget()
                WidgetRegistry.shared.registerPhotoWidget()
            }
            
            resolveAllWidgetOverlaps()
            viewModel.compactPages()
            currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
        }
        .sheet(isPresented: $showAddWidgetSheet) {
            AddWidgetSheetView(isPresented: $showAddWidgetSheet, viewModel: viewModel, currentPage: $currentPage)
        }
        .photosPicker(isPresented: $showInsPhotoPicker, selection: $selectedInsPostPhotoItem, matching: .images)
        .task(id: selectedWidgetPhotoItem) {
            if let data = try? await selectedWidgetPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.3)) { photoWidgetManager.widgetImageData = data }
            }
        }
        .task(id: selectedKoreanPhotoItem) {
            if let data = try? await selectedKoreanPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.3)) { koreanWidgetManager.widgetImageData = data }
            }
        }
        .task(id: selectedInsPostPhotoItem) {
            if let data = try? await selectedInsPostPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.3)) { insWidgetManager.postImageData = data }
            }
        }
    }
    
    private func topHeaderContainerView(headerH: CGFloat) -> some View {
        ZStack(alignment: .bottom) {
            if viewModel.isEditing {
                editHeaderView(headerH: headerH)
                    .transition(.opacity)
            } else {
                statusBarView(headerH: headerH)
                    .opacity(appearance.hideStatusBar ? 0.0 : 1.0)
                    .transition(.opacity)
            }
        }
        .frame(height: headerH, alignment: .bottom)
        .animation(.easeInOut(duration: 0.22), value: viewModel.isEditing)
        .animation(.easeInOut(duration: 0.22), value: appearance.hideStatusBar)
    }
    
    private func editHeaderView(headerH: CGFloat) -> some View {
        HStack {
            Button(action: {
                impactFeedback.impactOccurred()
                showAddWidgetSheet = true
            }) {
                HStack(spacing: 4) {
                    Image(systemName: "plus").font(.system(size: 11, weight: appearance.systemFontWeight))
                    Text(lang.tr("edit")).font(.system(size: 13, weight: appearance.systemFontWeight))
                }
                .foregroundColor(contentColor)
                .padding(.horizontal, 12).padding(.vertical, 4)
                .background(.ultraThinMaterial).clipShape(Capsule())
            }
            Spacer()
            Button(action: { exitEditMode() }) {
                Text(lang.tr("done"))
                    .font(.system(size: 13, weight: appearance.systemFontWeight))
                    .foregroundColor(contentColor)
                    .padding(.horizontal, 14).padding(.vertical, 4)
                    .background(.ultraThinMaterial).clipShape(Capsule())
            }
        }
        .padding(.horizontal, 20)
        .frame(height: headerH, alignment: .bottom)
        .applyCustomAppearance(appearance)
    }
    
    private func statusBarView(headerH: CGFloat) -> some View {
        HStack {
            Text(lang.tr("carrier_name")).font(.caption).fontWeight(appearance.systemFontWeight)
            Spacer()
            Image(systemName: "wifi")
            Image(systemName: "battery.100")
        }
        .foregroundColor(contentColor)
        .padding(.horizontal, 24)
        .frame(height: headerH, alignment: .bottom)
    }
    
    private func gridContainerView(
        rootOrigin: CGPoint,
        screenW: CGFloat,
        screenH: CGFloat,
        headerH: CGFloat,
        rowPitch: CGFloat,
        rowSpacing: CGFloat,
        widget4xHeight: CGFloat,
        widget2xHeight: CGFloat,
        dockTriggerH: CGFloat
    ) -> some View {
        TabView(selection: $currentPage) {
            ForEach(Array(0..<viewModel.totalPages()), id: \.self) { pageIndex in
                let guaranteedSlots = viewModel.slotsForPage(pageIndex)
                VStack(spacing: 0) {
                    desktopPageOverlayLayout(
                        pageIndex: pageIndex,
                        guaranteedSlots: guaranteedSlots,
                        rootOrigin: rootOrigin,
                        screenW: screenW,
                        screenH: screenH,
                        rowPitch: rowPitch,
                        rowSpacing: rowSpacing,
                        widget4xHeight: widget4xHeight,
                        widget2xHeight: widget2xHeight,
                        dockTriggerH: dockTriggerH,
                        headerH: headerH
                    )
                    Spacer(minLength: 0)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .padding(.horizontal, 24)
                .tag(pageIndex)
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
    }
    
    @ViewBuilder
    private func desktopPageOverlayLayout(
        pageIndex: Int,
        guaranteedSlots: [(index: Int, item: AppItem?)],
        rootOrigin: CGPoint,
        screenW: CGFloat,
        screenH: CGFloat,
        rowPitch: CGFloat,
        rowSpacing: CGFloat,
        widget4xHeight: CGFloat,
        widget2xHeight: CGFloat,
        dockTriggerH: CGFloat,
        headerH: CGFloat
    ) -> some View {
        let fullWidth = max(0, screenW - 48)
        let halfWidth = max(0, (fullWidth - 18) / 2.0)
        
        ZStack(alignment: .topLeading) {
            LazyVGrid(columns: columns, spacing: rowSpacing) {
                ForEach(guaranteedSlots, id: \.index) { slot in
                    gridCell(
                        slot: slot,
                        rootOrigin: rootOrigin,
                        screenW: screenW,
                        screenH: screenH,
                        dockTriggerH: dockTriggerH,
                        headerH: headerH,
                        rowPitch: rowPitch
                    )
                }
            }
            .zIndex(0)
            
            // 4×4 组件：占满 4 列宽，底边精准平齐第 4 排图标底边（300 + 3S）
            if insWidgetManager.isAddedToDesktop && insWidgetManager.widgetPage == pageIndex {
                desktopInsWidgetView(rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, rowPitch: rowPitch, dockTriggerH: dockTriggerH)
                    .frame(width: fullWidth, height: widget4xHeight)
                    .clipped()
                    .offset(y: CGFloat(insWidgetManager.widgetRow) * rowPitch)
                    .zIndex(1)
                    .opacity(widgetCoordinator.activeType == .ins ? 0.0 : 1.0)
                    .transition(.identity)
                    .id("ins_post_widget_\(pageIndex)")
            }
            
            // 2×2 / 4×2 组件：占半宽（2列），底边精准平齐第 2 排图标底边（140 + S）
            if koreanWidgetManager.isAddedToDesktop && koreanWidgetManager.widgetPage == pageIndex {
                desktopKoreanWidgetView(rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, rowPitch: rowPitch, dockTriggerH: dockTriggerH)
                    .frame(width: halfWidth, height: widget2xHeight)
                    .clipped()
                    .offset(
                        x: koreanWidgetManager.widgetCol == 0 ? 0 : (halfWidth + 18),
                        y: CGFloat(koreanWidgetManager.widgetRow) * rowPitch
                    )
                    .zIndex(2)
                    .opacity(widgetCoordinator.activeType == .korean ? 0.0 : 1.0)
                    .transition(.identity)
                    .id("korean_msg_widget_\(pageIndex)")
            }
            
            // 照片组件（4列宽）
            if photoWidgetManager.isAddedToDesktop && photoWidgetManager.widgetPage == pageIndex {
                desktopPhotoWidgetView(rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, rowPitch: rowPitch, dockTriggerH: dockTriggerH)
                    .frame(width: fullWidth, height: widget2xHeight)
                    .clipped()
                    .offset(y: CGFloat(photoWidgetManager.widgetRow) * rowPitch)
                    .zIndex(3)
                    .opacity(widgetCoordinator.activeType == .photo ? 0.0 : 1.0)
                    .transition(.identity)
                    .id("photo_widget_\(pageIndex)")
            }
            
            // 气泡组件（2列宽）
            if chatBubbleManager.isAddedToDesktop && chatBubbleManager.widgetPage == pageIndex {
                desktopBubbleWidgetView(rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, halfWidth: halfWidth, rowPitch: rowPitch, dockTriggerH: dockTriggerH)
                    .frame(width: halfWidth, height: widget2xHeight)
                    .clipped()
                    .offset(
                        x: chatBubbleManager.widgetCol == 0 ? 0 : (halfWidth + 18),
                        y: CGFloat(chatBubbleManager.widgetRow) * rowPitch
                    )
                    .zIndex(4)
                    .opacity(widgetCoordinator.activeType == .bubble ? 0.0 : 1.0)
                    .transition(.identity)
                    .id("bubble_widget_\(pageIndex)")
            }
        }
        .contentShape(Rectangle())
        .onTapGesture {
            guard Date().timeIntervalSince(lastEditTriggerTime) > 0.4 else { return }
            if viewModel.isEditing { exitEditMode() }
        }
        .simultaneousGesture(
            LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                if !viewModel.isEditing { enterEditMode() }
            }
        )
    }
    
    private func gridCell(
        slot: (index: Int, item: AppItem?),
        rootOrigin: CGPoint,
        screenW: CGFloat,
        screenH: CGFloat,
        dockTriggerH: CGFloat,
        headerH: CGFloat,
        rowPitch: CGFloat
    ) -> some View {
        GridSlotView(
            slotIndex: slot.index,
            item: slot.item,
            isEditing: viewModel.isEditing,
            isBeingDragged: dragCoordinator.activeDraggingItem?.id == slot.item?.id,
            textColor: contentColor,
            customTitle: slot.item != nil ? iconManager.getTitle(for: slot.item!.id) : nil,
            customImageData: slot.item != nil ? iconManager.getIcon(for: slot.item!.id) : nil,
            onLaunch: { if let item = slot.item { handleAppLaunch(item) } },
            onEnterEdit: { enterEditMode() },
            onDragStart: { item, globalPos in dragCoordinator.start(item: item, source: .grid(slot.index), location: globalPos) },
            onDragChange: { globalPos in
                dragCoordinator.update(location: globalPos)
                let local = CGPoint(x: globalPos.x - rootOrigin.x, y: globalPos.y - rootOrigin.y)
                handleAppEdgeDrag(location: local, screenW: screenW, screenH: screenH, dockTriggerH: dockTriggerH)
            },
            onDragEnd: { globalPos in
                cancelEdgePaging()
                finishDragInstantly(globalPos: globalPos, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, dockTriggerH: dockTriggerH, headerH: headerH, rowPitch: rowPitch)
            }
        )
    }
    
    private func desktopInsWidgetView(rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat, rowPitch: CGFloat, dockTriggerH: CGFloat) -> some View {
        InsPostWidget4x4View(
            manager: insWidgetManager,
            isEditing: viewModel.isEditing,
            onDelete: {
                impactFeedback.impactOccurred()
                withAnimation(.easeInOut(duration: 0.22)) {
                    insWidgetManager.isAddedToDesktop = false
                    viewModel.compactPages()
                    currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
                }
            },
            onDeletePostImage: { withAnimation { insWidgetManager.postImageData = nil } },
            onSelectPostImage: { if !viewModel.isEditing { showInsPhotoPicker = true } } 
        )
        .modifier(JiggleModifier(isEditing: viewModel.isEditing, isWidget: true, customDelayIndex: 0))
        .highPriorityGesture(
            DragGesture(minimumDistance: 8, coordinateSpace: .global)
                .onChanged { val in
                    guard viewModel.isEditing else { return }
                    if widgetCoordinator.activeType == nil {
                        impactFeedback.impactOccurred()
                        widgetCoordinator.start(type: .ins, originX: 0, originY: CGFloat(insWidgetManager.widgetRow) * rowPitch)
                    }
                    if !isPagingAnimating {
                        widgetCoordinator.update(translation: val.translation)
                    }
                    let localTouch = CGPoint(x: val.location.x - rootOrigin.x, y: val.location.y - rootOrigin.y)
                    handleAppEdgeDrag(location: localTouch, screenW: screenW, screenH: screenH, dockTriggerH: dockTriggerH)
                }
                .onEnded { _ in
                    guard viewModel.isEditing else { return }
                    cancelEdgePaging()
                    finishWidgetDrag(type: .ins, screenW: screenW, rowPitch: rowPitch)
                }
        )
    }
    
    private func desktopKoreanWidgetView(rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat, rowPitch: CGFloat, dockTriggerH: CGFloat) -> some View {
        KoreanMessageWidget4x2View(
            manager: koreanWidgetManager,
            isEditing: viewModel.isEditing,
            onDelete: {
                impactFeedback.impactOccurred()
                withAnimation(.easeInOut(duration: 0.22)) {
                    koreanWidgetManager.isAddedToDesktop = false
                    viewModel.compactPages()
                    currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
                }
            }
        )
        .modifier(JiggleModifier(isEditing: viewModel.isEditing, isWidget: true, customDelayIndex: 1))
        .highPriorityGesture(
            DragGesture(minimumDistance: 8, coordinateSpace: .global)
                .onChanged { val in
                    guard viewModel.isEditing else { return }
                    if widgetCoordinator.activeType == nil {
                        impactFeedback.impactOccurred()
                        let halfWidth = max(0, (screenW - 48 - 18) / 2.0)
                        let startX = koreanWidgetManager.widgetCol == 0 ? 0 : (halfWidth + 18.0)
                        widgetCoordinator.start(type: .korean, originX: startX, originY: CGFloat(koreanWidgetManager.widgetRow) * rowPitch)
                    }
                    if !isPagingAnimating {
                        widgetCoordinator.update(translation: val.translation)
                    }
                    let localTouch = CGPoint(x: val.location.x - rootOrigin.x, y: val.location.y - rootOrigin.y)
                    handleAppEdgeDrag(location: localTouch, screenW: screenW, screenH: screenH, dockTriggerH: dockTriggerH)
                }
                .onEnded { _ in
                    guard viewModel.isEditing else { return }
                    cancelEdgePaging()
                    finishWidgetDrag(type: .korean, screenW: screenW, rowPitch: rowPitch)
                }
        )
    }
    
    private func desktopPhotoWidgetView(rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat, rowPitch: CGFloat, dockTriggerH: CGFloat) -> some View {
        Group {
            if viewModel.isEditing {
                PhotoWidget4x2View(
                    imageData: photoWidgetManager.widgetImageData,
                    isEditing: true,
                    onDelete: {
                        impactFeedback.impactOccurred()
                        withAnimation(.easeInOut(duration: 0.22)) {
                            photoWidgetManager.isAddedToDesktop = false
                            viewModel.compactPages()
                            currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
                        }
                    }
                )
                .highPriorityGesture(
                    DragGesture(minimumDistance: 8, coordinateSpace: .global)
                        .onChanged { val in
                            if widgetCoordinator.activeType == nil {
                                impactFeedback.impactOccurred()
                                widgetCoordinator.start(type: .photo, originX: 0, originY: CGFloat(photoWidgetManager.widgetRow) * rowPitch)
                            }
                            if !isPagingAnimating {
                                widgetCoordinator.update(translation: val.translation)
                            }
                            let localTouch = CGPoint(x: val.location.x - rootOrigin.x, y: val.location.y - rootOrigin.y)
                            handleAppEdgeDrag(location: localTouch, screenW: screenW, screenH: screenH, dockTriggerH: dockTriggerH)
                        }
                        .onEnded { _ in
                            cancelEdgePaging()
                            finishWidgetDrag(type: .photo, screenW: screenW, rowPitch: rowPitch)
                        }
                )
            } else {
                PhotosPicker(selection: $selectedWidgetPhotoItem, matching: .images, photoLibrary: .shared()) {
                    PhotoWidget4x2View(imageData: photoWidgetManager.widgetImageData, isEditing: false)
                }
                .buttonStyle(.plain)
            }
        }
        .modifier(JiggleModifier(isEditing: viewModel.isEditing, isWidget: true, customDelayIndex: 2))
    }
    
    private func desktopBubbleWidgetView(rootOrigin: CGPoint, screenW: CGFloat, screenH: CGFloat, halfWidth: CGFloat, rowPitch: CGFloat, dockTriggerH: CGFloat) -> some View {
        ChatBubbleWidget2x2View(
            imageData: chatBubbleManager.widgetImageData,
            firstBubbleText: chatBubbleManager.firstBubbleText,
            secondBubbleText: chatBubbleManager.secondBubbleText,
            isTransparent: chatBubbleManager.isTransparentBackground,
            bubbleColor: chatBubbleManager.bubbleColor,
            bubbleTextColor: chatBubbleManager.bubbleTextColor,
            dateTextColor: chatBubbleManager.dateTextColor,
            bubbleTextWeight: chatBubbleManager.bubbleTextWeight,
            isEditing: viewModel.isEditing,
            showDashedBorder: false,
            onDelete: {
                impactFeedback.impactOccurred()
                withAnimation(.easeInOut(duration: 0.22)) {
                    chatBubbleManager.isAddedToDesktop = false
                    viewModel.compactPages()
                    currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
                }
            }
        )
        .modifier(JiggleModifier(isEditing: viewModel.isEditing, isWidget: true, customDelayIndex: 3))
        .highPriorityGesture(
            DragGesture(minimumDistance: 8, coordinateSpace: .global)
                .onChanged { val in
                    guard viewModel.isEditing else { return }
                    if widgetCoordinator.activeType == nil {
                        impactFeedback.impactOccurred()
                        let startX = chatBubbleManager.widgetCol == 0 ? 0 : (halfWidth + 18.0)
                        widgetCoordinator.start(type: .bubble, originX: startX, originY: CGFloat(chatBubbleManager.widgetRow) * rowPitch)
                    }
                    if !isPagingAnimating {
                        widgetCoordinator.update(translation: val.translation)
                    }
                    let localTouch = CGPoint(x: val.location.x - rootOrigin.x, y: val.location.y - rootOrigin.y)
                    handleAppEdgeDrag(location: localTouch, screenW: screenW, screenH: screenH, dockTriggerH: dockTriggerH)
                }
                .onEnded { _ in
                    guard viewModel.isEditing else { return }
                    cancelEdgePaging()
                    finishWidgetDrag(type: .bubble, screenW: screenW, rowPitch: rowPitch)
                }
        )
    }
    
    private func finishWidgetDrag(type: DraggingWidgetType, screenW: CGFloat, rowPitch: CGFloat) {
        impactFeedback.impactOccurred()
        let targetPage = currentPage
        
        let finalY = max(0, widgetCoordinator.initialOriginY + widgetCoordinator.positionTracker.offset.height)
        let finalX = max(0, widgetCoordinator.initialOriginX + widgetCoordinator.positionTracker.offset.width)
        let halfWidth = max(0, (screenW - 48 - 18) / 2.0)
        
        let targetRow = min(max(0, Int(round(finalY / rowPitch))), (type == .ins ? 2 : 4))
        let targetCol = (type == .bubble || type == .korean) ? ((finalX > (halfWidth / 2.0)) ? 2 : 0) : 0
        
        var noAnimationTrans = Transaction()
        noAnimationTrans.animation = nil 
        withTransaction(noAnimationTrans) {
            widgetCoordinator.reset()
            switch type {
            case .ins:
                insWidgetManager.widgetPage = targetPage
                insWidgetManager.widgetRow = targetRow
                resolveAllWidgetOverlaps(priority: insWidgetManager)
                
            case .korean:
                koreanWidgetManager.widgetPage = targetPage
                koreanWidgetManager.widgetRow = targetRow
                koreanWidgetManager.widgetCol = targetCol
                resolveAllWidgetOverlaps(priority: koreanWidgetManager)
                
            case .photo:
                photoWidgetManager.widgetPage = targetPage
                photoWidgetManager.widgetRow = targetRow
                resolveAllWidgetOverlaps(priority: photoWidgetManager)
                
            case .bubble:
                chatBubbleManager.widgetPage = targetPage
                chatBubbleManager.widgetRow = targetRow
                chatBubbleManager.widgetCol = targetCol
                resolveAllWidgetOverlaps(priority: chatBubbleManager)
            }
        }
        
        withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
            viewModel.compactPages()
            currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
        }
    }
    
    private func resolveAllWidgetOverlaps(priority: DesktopWidgetManager? = nil) {
        let allActive = WidgetRegistry.shared.activeManagers.filter { $0.isAddedToDesktop }
        guard allActive.count > 1 else { return }
        
        var resolved: [DesktopWidgetManager] = []
        if let priority = priority, priority.isAddedToDesktop {
            resolved.append(priority)
        }
        
        let remaining = allActive.filter { other in
            if let p = priority { return other !== p }
            return true
        }
        
        for w in remaining {
            let collides = resolved.contains { isWidgetsOverlapping(w, $0) }
            if !collides {
                resolved.append(w)
            } else {
                let candidateCols = (w.sizeCols >= 4) ? [0] : [0, 2]
                let maxRow = max(0, 6 - w.sizeRows)
                let candidateRows = Array(0...maxRow)
                
                var placed = false
                var p = w.widgetPage
                while !placed && p < 10 {
                    let sortedRows = candidateRows.sorted { abs($0 - w.widgetRow) < abs($1 - w.widgetRow) }
                    for r in sortedRows {
                        for c in candidateCols {
                            let wouldCollide = resolved.contains { other in
                                guard other.widgetPage == p else { return false }
                                let r1 = r..<(r + w.sizeRows)
                                let r2 = other.widgetRow..<(other.widgetRow + other.sizeRows)
                                let c1 = c..<(c + w.sizeCols)
                                let c2 = other.widgetCol..<(other.widgetCol + other.sizeCols)
                                return r1.overlaps(r2) && c1.overlaps(c2)
                            }
                            if !wouldCollide {
                                w.widgetPage = p
                                w.widgetRow = r
                                w.widgetCol = c
                                resolved.append(w)
                                placed = true
                                break
                            }
                        }
                        if placed { break }
                    }
                    p += 1
                }
            }
        }
    }
    
    private func isWidgetsOverlapping(_ w1: DesktopWidgetManager, _ w2: DesktopWidgetManager) -> Bool {
        guard w1.isAddedToDesktop && w2.isAddedToDesktop else { return false }
        guard w1.widgetPage == w2.widgetPage else { return false }
        
        let r1 = w1.widgetRow..<(w1.widgetRow + w1.sizeRows)
        let r2 = w2.widgetRow..<(w2.widgetRow + w2.sizeRows)
        let c1 = w1.widgetCol..<(w1.widgetCol + w1.sizeCols)
        let c2 = w2.widgetCol..<(w2.widgetCol + w2.sizeCols)
        
        return r1.overlaps(r2) && c1.overlaps(c2)
    }
    
    private func dockBarView(
        rootOrigin: CGPoint,
        screenW: CGFloat,
        screenH: CGFloat,
        dockH: CGFloat,
        dockBottom: CGFloat,
        dockTriggerH: CGFloat,
        headerH: CGFloat,
        rowPitch: CGFloat
    ) -> some View {
        let dockW = max(screenW - 30, 1)
        let itemW = dockW / 4.0
        
        return HStack(spacing: 0) {
            ForEach(Array(viewModel.dockApps.enumerated()), id: \.element.id) { index, item in
                DockItemView(
                    dockIndex: index,
                    item: item,
                    isEditing: viewModel.isEditing,
                    isBeingDragged: dragCoordinator.activeDraggingItem?.id == item.id,
                    customImageData: iconManager.getIcon(for: item.id),
                    onLaunch: { handleAppLaunch(item) },
                    onEnterEdit: { enterEditMode() },
                    onDragStart: { item, globalPos in dragCoordinator.start(item: item, source: .dock(index), location: globalPos) },
                    onDragChange: { globalPos in
                        dragCoordinator.update(location: globalPos)
                        let local = CGPoint(x: globalPos.x - rootOrigin.x, y: globalPos.y - rootOrigin.y)
                        handleAppEdgeDrag(location: local, screenW: screenW, screenH: screenH, dockTriggerH: dockTriggerH)
                    },
                    onDragEnd: { globalPos in
                        cancelEdgePaging()
                        finishDragInstantly(globalPos: globalPos, rootOrigin: rootOrigin, screenW: screenW, screenH: screenH, dockTriggerH: dockTriggerH, headerH: headerH, rowPitch: rowPitch)
                    }
                )
                .frame(width: itemW)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: dockH)
        .background(RoundedRectangle(cornerRadius: 32, style: .continuous).fill(.ultraThinMaterial))
        .padding(.horizontal, 15)
        .padding(.bottom, dockBottom)
        .applyCustomAppearance(appearance)
    }
    
    private func finishDragInstantly(
        globalPos: CGPoint,
        rootOrigin: CGPoint,
        screenW: CGFloat,
        screenH: CGFloat,
        dockTriggerH: CGFloat,
        headerH: CGFloat,
        rowPitch: CGFloat
    ) {
        guard let source = dragCoordinator.activeDragSource else {
            dragCoordinator.reset()
            return
        }
        let local = CGPoint(x: globalPos.x - rootOrigin.x, y: globalPos.y - rootOrigin.y)
        let destination = calculateTarget(at: local, source: source, screenW: screenW, screenH: screenH, dockTriggerH: dockTriggerH, headerH: headerH, rowPitch: rowPitch)
        
        var noAnimationTrans = Transaction()
        noAnimationTrans.animation = nil
        withTransaction(noAnimationTrans) {
            dragCoordinator.reset()
        }
        
        withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
            viewModel.moveItem(from: source, to: destination)
            viewModel.compactPages()
            currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
        }
    }
    
    private func calculateTarget(
        at location: CGPoint,
        source: AppLocation,
        screenW: CGFloat,
        screenH: CGFloat,
        dockTriggerH: CGFloat,
        headerH: CGFloat,
        rowPitch: CGFloat
    ) -> AppLocation {
        if location.y >= (screenH - dockTriggerH) {
            let dockW = max(screenW - 30, 1)
            let itemW = dockW / 4.0
            let dockCount = viewModel.dockApps.count
            
            let totalW = CGFloat(dockCount) * itemW
            let startX = (screenW - totalW) / 2.0
            let relativeX = location.x - startX
            
            let rawIdx = Int(round(relativeX / itemW))
            let targetDock = min(max(0, rawIdx), min(dockCount, 3))
            return .dock(targetDock)
        } else {
            let usableW = max(screenW - 48, 1)
            let colW = usableW / 4.0
            let col = min(max(0, Int((location.x - 24) / colW)), 3)
            let targetRow = min(max(0, Int((location.y - headerH) / rowPitch)), 5)
            let pageBase = currentPage * viewModel.pageSize
            let targetGrid = pageBase + targetRow * 4 + col
            return .grid(targetGrid)
        }
    }
    
    private var indicatorView: some View {
        let isDotsMode = (viewModel.totalPages() > 1) && (viewModel.isEditing || showDotsTemporarily)
        
        return ZStack {
            if isDotsMode {
                HStack(spacing: 6) {
                    ForEach(Array(0..<viewModel.totalPages()), id: \.self) { idx in
                        Circle()
                            .fill(contentColor.opacity(currentPage == idx ? 1.0 : 0.35))
                            .frame(width: 5.5, height: 5.5)
                    }
                }
                .padding(.horizontal, 11)
                .frame(height: 26)
                .transition(.opacity)
            } else {
                HStack(spacing: 4) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 9.5, weight: appearance.systemFontWeight))
                    Text(lang.tr("search"))
                        .font(.system(size: 11, weight: appearance.systemFontWeight))
                }
                .foregroundColor(contentColor.opacity(0.95))
                .padding(.horizontal, 10.5)
                .frame(height: 26)
                .transition(.opacity)
            }
        }
        .background(
            Capsule()
                .fill(.ultraThinMaterial)
        )
        .applyCustomAppearance(appearance)
        .animation(.spring(response: 0.28, dampingFraction: 0.85), value: isDotsMode)
        .frame(height: 26)
        .onChange(of: currentPage) { _, _ in
            guard !viewModel.isEditing && viewModel.totalPages() > 1 else { return }
            withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                showDotsTemporarily = true
            }
            hideDotsTimer?.cancel()
            hideDotsTimer = Task {
                try? await Task.sleep(nanoseconds: 1_200_000_000)
                guard !Task.isCancelled else { return }
                withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                    showDotsTemporarily = false
                }
            }
        }
    }
    
    private var homeIndicatorBar: some View {
        Capsule()
            .fill(contentColor.opacity(0.5))
            .frame(width: 130, height: 5)
            .padding(.bottom, 6)
    }
    
    private var lockDragGesture: some Gesture {
        DragGesture(minimumDistance: 20)
            .onEnded { value in
                guard !viewModel.isEditing else { return }
                if value.translation.height > 50 { withAnimation(.easeInOut(duration: 0.4)) { isUnlocked = false } }
            }
    }
    
    private func handleAppLaunch(_ item: AppItem) {
        if AppRegistry.shared.registeredApps.keys.contains(item.id) {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.86)) {
                activeAppId = item.id
            }
        } else {
            UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
        }
    }
}

struct AddWidgetSheetView: View {
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: HomeScreenViewModel 
    @Binding var currentPage: Int
    @ObservedObject var lang = LanguageManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var registry = WidgetRegistry.shared 
    
    @State private var selectedCategory: String = "全部"
    private let sizeCategories = ["全部", "4×4", "4×2", "2×2"]
    @State private var selectedIndex: Int = 0
    
    private var filteredWidgets: [WidgetDefinition] {
        if selectedCategory == "全部" { return registry.registeredWidgets }
        return registry.registeredWidgets.filter { isWidgetMatchingCategory(widget: $0, category: selectedCategory) }
    }
    
    private func isWidgetMatchingCategory(widget: WidgetDefinition, category: String) -> Bool {
        if category == "全部" { return true }
        
        let normalize: (String) -> String = { str in
            str.lowercased()
                .replacingOccurrences(of: "badge_", with: "")
                .replacingOccurrences(of: "×", with: "x")
                .replacingOccurrences(of: "*", with: "x")
                .trimmingCharacters(in: .whitespaces)
        }
        
        let target = normalize(category)
        let badge = normalize(widget.sizeBadgeKey)
        let translatedBadge = normalize(lang.tr(widget.sizeBadgeKey))
        
        if badge == target || translatedBadge == target || badge.contains(target) {
            return true
        }
        
        switch target {
        case "2x2":
            return widget.sizeCols == 2 && widget.sizeRows == 2
        case "4x2":
            return (widget.sizeCols == 4 && widget.sizeRows == 2) || (widget.sizeCols == 2 && widget.sizeRows == 4)
        case "4x4":
            return widget.sizeCols == 4 && widget.sizeRows == 4
        default:
            return false
        }
    }
    
    private var activeWidget: WidgetDefinition? {
        guard selectedIndex >= 0 && selectedIndex < filteredWidgets.count else { return nil }
        return filteredWidgets[selectedIndex]
    }
    
    private var isCurrentAdded: Bool {
        activeWidget?.manager.isAddedToDesktop ?? false
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 8) {
                    ForEach(sizeCategories, id: \.self) { cat in
                        Button(action: {
                            UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            withAnimation(.easeInOut(duration: 0.2)) {
                                selectedCategory = cat
                                selectedIndex = 0
                            }
                        }) {
                            Text(cat == "全部" ? lang.tr("cat_all") : cat)
                                .font(.system(size: 13, weight: selectedCategory == cat ? .semibold : appearance.systemFontWeight))
                                .padding(.horizontal, 14).padding(.vertical, 6)
                                .background(selectedCategory == cat ? Color.blue : Color(UIColor.secondarySystemFill))
                                .foregroundColor(selectedCategory == cat ? .white : .primary)
                                .clipShape(Capsule())
                        }
                    }
                    Spacer()
                }
                .padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 8)
                
                TabView(selection: $selectedIndex) {
                    ForEach(Array(filteredWidgets.enumerated()), id: \.element.id) { index, item in
                        VStack(spacing: 0) {
                            Spacer(minLength: 8)
                            item.previewView()
                            Spacer(minLength: 12)
                            VStack(spacing: 5) {
                                HStack(spacing: 6) {
                                    Text(lang.tr(item.titleKey)).font(.system(size: 19, weight: appearance.systemFontWeight)).foregroundColor(.primary)
                                    Text(lang.tr(item.sizeBadgeKey)).font(.system(size: 11, weight: appearance.systemFontWeight))
                                        .padding(.horizontal, 6).padding(.vertical, 2).background(Color.blue.opacity(0.12)).foregroundColor(.blue).clipShape(Capsule())
                                }
                                Text(lang.tr(item.subtitleKey)).font(.caption).fontWeight(appearance.systemFontWeight).foregroundColor(.secondary).multilineTextAlignment(.center)
                            }
                            .padding(.horizontal, 20)
                            Spacer(minLength: 12)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: filteredWidgets.count > 1 ? .automatic : .never))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                Button(action: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    
                    if let def = activeWidget {
                        if def.manager.isAddedToDesktop {
                            withAnimation(.easeInOut(duration: 0.22)) {
                                def.manager.isAddedToDesktop = false
                                viewModel.compactPages()
                                currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
                            }
                        } else {
                            let target = viewModel.findAvailableSlot(
                                forRows: def.sizeRows,
                                forCols: def.sizeCols,
                                preferPage: currentPage
                            )
                            def.manager.widgetPage = target.page
                            def.manager.widgetRow = target.row
                            def.manager.widgetCol = target.col
                            
                            withAnimation(.easeInOut(duration: 0.22)) {
                                def.manager.isAddedToDesktop = true
                                viewModel.compactPages()
                                currentPage = target.page
                            }
                        }
                    }
                    isPresented = false
                }) {
                    HStack(spacing: 8) {
                        if isCurrentAdded {
                            Image(systemName: "checkmark.circle.fill").font(.system(size: 16, weight: appearance.systemFontWeight))
                            Text(lang.tr("already_added")).font(.system(size: 16, weight: appearance.systemFontWeight))
                        } else {
                            Image(systemName: "plus.circle.fill").font(.system(size: 16, weight: appearance.systemFontWeight))
                            Text(lang.tr("add_to_home")).font(.system(size: 16, weight: appearance.systemFontWeight))
                        }
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 14)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .padding(.horizontal, 24).padding(.bottom, 28)
            }
            .fontWeight(appearance.systemFontWeight)
            .navigationTitle(lang.tr("add_widget_nav_title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(lang.tr("close")) { isPresented = false }
                        .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
            .presentationDetents([.fraction(0.85), .large])
        }
    }
}
