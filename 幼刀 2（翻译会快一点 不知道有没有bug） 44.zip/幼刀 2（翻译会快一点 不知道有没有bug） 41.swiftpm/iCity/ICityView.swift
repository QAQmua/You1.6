import SwiftUI

struct ICityView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Image(systemName: "building.2.fill")
                    .font(.system(size: 64))
                    .foregroundColor(.blue)
                
                Text("iCity 建设中...".tr)
                    .font(.system(size: 18, weight: appearance.systemFontWeight))
                    .foregroundColor(.secondary)
            }
            .navigationTitle(lang.tr("app_icity"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                    }
                }
            }
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        // 支持右滑退出手势
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
    }
}
