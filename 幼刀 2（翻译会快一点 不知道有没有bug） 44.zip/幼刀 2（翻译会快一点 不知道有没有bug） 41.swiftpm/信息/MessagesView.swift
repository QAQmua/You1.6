import SwiftUI

struct MessageChatPreview: Identifiable {
    let id = UUID()
    let sender: String
    let preview: String
    let time: String
    let isUnread: Bool
    let avatarColor: Color
}

struct MessagesView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    
    @State private var messages: [MessageChatPreview] = [
        MessageChatPreview(sender: "Apple", preview: "您的 Apple ID 验证码为 892104。请勿告知他人。", time: "10:24", isUnread: true, avatarColor: .gray),
        MessageChatPreview(sender: "中国联通", preview: "本月套餐剩余高速流量 32.5 GB，话费余额充裕。", time: "昨天", isUnread: false, avatarColor: .blue),
        MessageChatPreview(sender: "快递驿站", preview: "您的顺丰包裹已到达自提柜，取件码 5-201。", time: "周四", isUnread: false, avatarColor: .orange)
    ]
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(messages) { msg in
                        HStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(msg.avatarColor.opacity(0.18))
                                    .frame(width: 44, height: 44)
                                Image(systemName: "person.fill")
                                    .foregroundColor(msg.avatarColor)
                            }
                            
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(msg.sender)
                                        .font(.system(size: 16, weight: appearance.systemFontWeight))
                                        .foregroundColor(.primary)
                                    Spacer()
                                    Text(msg.time)
                                        .font(.system(size: 12))
                                        .foregroundColor(.secondary)
                                }
                                
                                Text(msg.preview)
                                    .font(.system(size: 13))
                                    .foregroundColor(.secondary)
                                    .lineLimit(2)
                            }
                            
                            if msg.isUnread {
                                Circle()
                                    .fill(Color.blue)
                                    .frame(width: 8, height: 8)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle(lang.tr("app_messages"))
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                    }
                }
            }
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
    }
}
