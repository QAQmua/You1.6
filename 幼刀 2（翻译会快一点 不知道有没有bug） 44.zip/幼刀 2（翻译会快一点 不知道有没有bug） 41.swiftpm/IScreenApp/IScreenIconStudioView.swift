// 📄 新文件：IScreenIconStudioView.swift
import SwiftUI
import PhotosUI

struct IScreenIconStudioView: View {
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var iconManager = CustomIconManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    @State private var selectedAppPhotoItem: PhotosPickerItem? = nil
    @State private var targetAppForCustomIcon: String? = nil
    @State private var showRenameAlert: Bool = false
    @State private var editingAppIdForRename: String? = nil
    @State private var inputAppName: String = ""
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Image(systemName: "photo.stack.fill").font(.system(size: 22, weight: .bold)).foregroundColor(.blue)
                        Text("应用图标灵动工坊".tr).font(.system(size: 19, weight: appearance.systemFontWeight))
                        Spacer()
                        Text("iOS 26 驱动".tr).font(.system(size: 10, weight: .bold)).padding(.horizontal, 8).padding(.vertical, 4).background(Color.blue.opacity(0.15)).foregroundColor(.blue).clipShape(Capsule())
                    }
                    Text("点按右侧直接调取本地相册更换图片；点击名称或编辑图标即可自定义 App 软件名称。".tr).font(.caption).foregroundColor(.secondary).lineSpacing(3)
                }
                .padding(18).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(22)
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.primary.opacity(0.06), lineWidth: 1))
                .padding(.horizontal, 16).padding(.top, 8)
                
                let apps = AppRegistry.shared.allApps
                let customizedAppCount = apps.filter { iconManager.getIcon(for: $0.id) != nil || iconManager.getTitle(for: $0.id) != nil }.count
                
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text("桌面应用列表".tr).font(.system(size: 14, weight: appearance.systemFontWeight))
                        Spacer()
                        Text("\("已定制".tr) \(customizedAppCount) \("款".tr)").font(.caption).foregroundColor(.secondary)
                    }.padding(.horizontal, 16)
                    
                    VStack(spacing: 12) {
                        ForEach(apps, id: \.id) { app in
                            appIconCustomizerRow(
                                appId: app.id,
                                appName: app.defaultName,
                                defaultIcon: app.defaultIcon,
                                defaultColor: colorMapping(app.defaultColorName)
                            )
                        }
                    }.padding(.horizontal, 16)
                }
            }
            .padding(.bottom, 20)
        }
        .alert("自定义应用名称".tr, isPresented: $showRenameAlert) {
            TextField("输入应用名称".tr, text: $inputAppName)
            Button("保存".tr) {
                if let appId = editingAppIdForRename {
                    iconManager.setTitle(for: appId, title: inputAppName)
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                }
            }
            Button("恢复默认名称".tr, role: .destructive) {
                if let appId = editingAppIdForRename { iconManager.removeTitle(for: appId) }
            }
            Button("取消".tr, role: .cancel) {}
        } message: { Text("修改后的名称将实时在桌面和系统各处生效。".tr) }
            .task(id: selectedAppPhotoItem) {
                if let item = selectedAppPhotoItem, let appId = targetAppForCustomIcon {
                    if let data = try? await item.loadTransferable(type: Data.self) {
                        withAnimation(.easeInOut(duration: 0.25)) { iconManager.setIcon(for: appId, imageData: data) }
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                    }
                    selectedAppPhotoItem = nil
                    targetAppForCustomIcon = nil
                }
            }
    }
    
    private func appIconCustomizerRow(appId: String, appName: String, defaultIcon: String, defaultColor: Color) -> some View {
        let customData = iconManager.getIcon(for: appId)
        let customTitle = iconManager.getTitle(for: appId)
        let displayName = customTitle != nil ? customTitle! : appName.tr
        let isIconCustomized = customData != nil
        let isTitleCustomized = customTitle != nil
        let isCustomized = isIconCustomized || isTitleCustomized
        
        return HStack(spacing: 12) {
            Group {
                if let data = customData, let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage).resizable().scaledToFill().frame(width: 48, height: 48).clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous)).overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.primary.opacity(0.08), lineWidth: 1))
                } else {
                    Image(systemName: defaultIcon).font(.system(size: 22)).foregroundColor(.white).frame(width: 48, height: 48).background(defaultColor).clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
            }
            
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Button(action: { editingAppIdForRename = appId; inputAppName = displayName; showRenameAlert = true }) {
                        HStack(spacing: 4) {
                            Text(translator.translate(displayName)).font(.system(size: 15, weight: appearance.systemFontWeight)).foregroundColor(.primary).lineLimit(1)
                            Image(systemName: "pencil").font(.system(size: 11, weight: .semibold)).foregroundColor(.secondary)
                        }
                    }.buttonStyle(.plain)
                    if isCustomized { Text("已定制".tr).font(.system(size: 9, weight: .bold)).padding(.horizontal, 5).padding(.vertical, 2).background(Color.blue.opacity(0.12)).foregroundColor(.blue).clipShape(Capsule()) }
                }
                Text(isCustomized ? "\("自定义".tr)\(appName.tr)\("图标".tr)" : "\("系统默认".tr)\(appName.tr)\("图标".tr)").font(.caption2).foregroundColor(.secondary).lineLimit(1)
            }.frame(maxWidth: .infinity, alignment: .leading)
            
            HStack(spacing: 6) {
                if isCustomized {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.easeInOut(duration: 0.2)) { iconManager.removeIcon(for: appId); iconManager.removeTitle(for: appId) }
                    }) { Image(systemName: "arrow.counterclockwise").font(.system(size: 11, weight: .bold)).foregroundColor(.secondary).frame(width: 28, height: 28).background(Color(UIColor.secondarySystemFill)).clipShape(Circle()) }
                }
                PhotosPicker(selection: $selectedAppPhotoItem, matching: .images, photoLibrary: .shared()) {
                    HStack(spacing: 4) {
                        Image(systemName: "photo.badge.plus").font(.system(size: 11, weight: .semibold))
                        Text(isIconCustomized ? "更换".tr : "选图".tr).font(.system(size: 12, weight: appearance.systemFontWeight))
                    }
                    .foregroundColor(.white).padding(.horizontal, 11).padding(.vertical, 6).background(Color.blue).clipShape(Capsule())
                }.simultaneousGesture(TapGesture().onEnded { targetAppForCustomIcon = appId })
            }
        }
        .frame(maxWidth: .infinity).padding(.horizontal, 14).padding(.vertical, 12).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18)
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.primary.opacity(0.06), lineWidth: 1))
    }
    
    private func colorMapping(_ name: String) -> Color {
        switch name {
        case "gray": return .gray; case "green": return .green; case "blue": return .blue
        case "orange": return .orange; case "red": return .red; case "purple": return .purple
        default: return .gray
        }
    }
}
