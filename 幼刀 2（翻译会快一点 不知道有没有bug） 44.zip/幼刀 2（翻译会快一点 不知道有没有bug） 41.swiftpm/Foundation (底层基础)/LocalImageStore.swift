// MARK: - LocalImageStore.swift (本地沙盒磁盘 + 高速内存缓存中心 · 串行安全版)
import UIKit

final class LocalImageStore {
    static let shared = LocalImageStore()
    
    private let fileManager = FileManager.default
    private let memCache = NSCache<NSString, NSData>()
    // 严格保证磁盘写与删的时序一致性，杜绝多任务竞争删错新图
    private let diskQueue = DispatchQueue(label: "com.app.localimagestore.disk", qos: .utility)
    
    private lazy var folderURL: URL = {
        let paths = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask)
        let dir = paths[0].appendingPathComponent("AppImages", isDirectory: true)
        if !fileManager.fileExists(atPath: dir.path) {
            try? fileManager.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }()
    
    func save(data: Data?) -> String? {
        guard let data = data, !data.isEmpty else { return nil }
        let id = UUID().uuidString
        let fileURL = folderURL.appendingPathComponent(id)
        memCache.setObject(data as NSData, forKey: id as NSString)
        do {
            try data.write(to: fileURL)
            return id
        } catch {
            return nil
        }
    }
    
    func load(id: String?) -> Data? {
        guard let id = id, !id.isEmpty else { return nil }
        if let cached = memCache.object(forKey: id as NSString) {
            return cached as Data
        }
        let fileURL = folderURL.appendingPathComponent(id)
        if let data = try? Data(contentsOf: fileURL) {
            memCache.setObject(data as NSData, forKey: id as NSString)
            return data
        }
        return nil
    }
    
    func delete(id: String?) {
        guard let id = id, !id.isEmpty else { return }
        memCache.removeObject(forKey: id as NSString)
        let fileURL = folderURL.appendingPathComponent(id)
        try? fileManager.removeItem(at: fileURL)
    }
    
    // 安全原子置换：先存新图后删旧图，回到主线程更新 Key
    func replace(oldId: String?, with newData: Data?, completion: @escaping (String?) -> Void) {
        diskQueue.async { [weak self] in
            guard let self = self else { return }
            let newId = self.save(data: newData)
            if let oldId = oldId, oldId != newId {
                self.delete(id: oldId)
            }
            DispatchQueue.main.async {
                completion(newId)
            }
        }
    }
}
