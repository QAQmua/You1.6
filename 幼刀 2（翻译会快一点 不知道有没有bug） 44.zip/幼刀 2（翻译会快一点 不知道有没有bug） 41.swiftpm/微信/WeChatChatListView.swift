// 📄 替换文件：33.swiftpm/微信/WeChatChatListView.swift
import SwiftUI

struct WeChatChatListView: View {
    @ObservedObject var viewModel: WeChatViewModel
    @ObservedObject var appearance = SystemAppearance.shared
    
    var body: some View {
        List {
            // 搜索框占位
            HStack {
                Image(systemName: "magnifyingglass").foregroundColor(.gray)
                Text("搜索".tr).foregroundColor(.gray)
                Spacer()
            }
            .font(.system(size: 15))
            .padding(.vertical, 8)
            .padding(.horizontal, 12)
            .background(Color(UIColor.secondarySystemFill))
            .cornerRadius(6)
            .listRowSeparator(.hidden)
            .padding(.vertical, 4)
            
            // 聊天列表
            ForEach(viewModel.chatList) { chat in
                HStack(spacing: 12) {
                    // 1. 微信标准圆角头像 + 未读红点
                    ZStack(alignment: .topTrailing) {
                        Image(systemName: "person.crop.square.fill")
                            .resizable()
                            .frame(width: 48, height: 48)
                            .foregroundColor(chat.avatarColor.opacity(0.8))
                            .background(chat.avatarColor.opacity(0.2))
                            .cornerRadius(8)
                        
                        // 🌟 未读消息红点
                        if chat.unreadCount > 0 {
                            Text("\(chat.unreadCount)")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(.white)
                                .padding(.horizontal, chat.unreadCount > 9 ? 6 : 4)
                                .padding(.vertical, 2)
                                .background(Color.red)
                                .clipShape(Capsule())
                                .offset(x: 10, y: -8)
                        }
                    }
                    
                    // 2. 昵称与消息
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(alignment: .top) {
                            Text(chat.name.tr)
                                .font(.system(size: 17, weight: .regular))
                                .foregroundColor(.primary)
                            Spacer()
                            // 3. 时间靠右上角
                            Text(chat.time.tr)
                                .font(.system(size: 12))
                                .foregroundColor(.secondary)
                        }
                        
                        Text(chat.message.tr)
                            .font(.system(size: 14))
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                }
                .padding(.vertical, 6)
                // 确保分割线和文本对齐，避免穿透头像
                .alignmentGuide(.listRowSeparatorLeading) { _ in
                    return 72
                }
            }
        }
        .listStyle(.plain)
    }
}
